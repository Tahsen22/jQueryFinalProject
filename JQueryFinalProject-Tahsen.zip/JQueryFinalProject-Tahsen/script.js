$(document).ready(function(){
    // Hide about section ========>
    $("#about").hide();
    $("#aboutdown").click(function(){
        $("#about").slideDown();
        $("#about").css("visibility", "visible");
    });
    // Contact Info ===========>
    $('#showContact').click(function(){
        $('#contactInfo').load("info.txt");
    });
    // typed ====================>
    var typed = new Typed("#element", {
        strings: ["Content Creator", "Content Scheduling", "Search Engine Optomization (SEO)", "Email Marketing", "Buseness Management and Planing", "Social Media Marketing", ],
        smartBackspace:true,
        typeSpeed:100,
        backSpeed:100,
        loop:true,
        loopCount:Infinity,
        startDelay:1000
    });


var p = document.querySelectorAll('.progress-bar');
p[0].setAttribute("style", "width:95%; transation:1s all");
p[1].setAttribute("style", "width:90%; transation:1.5s all");
p[2].setAttribute("style", "width:88%; transation:1.7s all");
p[3].setAttribute("style", "width:93%; transation:2s all");
p[4].setAttribute("style", "width:95%; transation:2.3s all");

});
