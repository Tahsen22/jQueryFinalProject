function timeDate() {
    const time =<h2 style={{color:"#762b8d"}}>{new Date().toLocaleString()}</h2>;
    ReactDOM.render(time, document.getElementById('cTime'));
}
setInterval(timeDate, 1000);